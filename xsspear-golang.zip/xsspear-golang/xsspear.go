package main

import (
	"flag"
	"bufio"
	"bytes"
	"fmt"
	"io"
	"net/http"
	"net/url"  // Importing the correct `net/url` package
	"os"
	"os/exec"
	"regexp"
	"sync"
	"log"
)

func main() {
	// Define a string flag for the URL with a default value of "google.com"
	targetURL := flag.String("t", "google.com", "URL to query the Wayback Machine for")

	// Parse the command-line arguments
	flag.Parse()

	// First, run the curl command
	curlCmd := exec.Command("curl", "-s", fmt.Sprintf("https://web.archive.org/cdx/search/cdx?url=%s&matchType=domain&fl=original&collapse=urlkey", *targetURL))
		
	// Run the command and get the output (stdout)
	curlOut, err := curlCmd.Output()
	if err != nil {
		log.Fatalf("Error executing curl command: %v", err)
	}

	// Next, pipe the output of curl to the 'uro' command
	uroCmd := exec.Command("uro")

	// Set the input of the 'uro' command to the output of the curl command
	uroCmd.Stdin = bytes.NewReader(curlOut)

	// Run the uro command and capture its output
	uroOut, err := uroCmd.Output()
	if err != nil {
		log.Fatalf("Error executing uro command: %v", err)
	}

	// Finally, write the output to the file urls.txt
	err = os.WriteFile("urls.txt", uroOut, 644)
	if err != nil {
		log.Fatalf("Error writing to file: %v", err)
	}

	// Open the file containing the links
	file, err := os.Open("urls.txt")
	if err != nil {
		fmt.Printf("Error opening file: %v\n", err)
		return
	}
	defer file.Close()

	// Read links from the file into a slice
	var links []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		links = append(links, scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		fmt.Printf("Error reading file: %v\n", err)
		return
	}

	// WaitGroup to wait for all goroutines to finish
	var wg sync.WaitGroup

	// Iterate through the list of links (sequentially)
	for i, link := range links {
		// Removed parallelism from the main loop
		fmt.Printf("[%d] URL: %s\n", i+1, link)

		// Send a GET request to the link
		response, err := http.Get(link)
		if err != nil {
			fmt.Printf("Error fetching %s: %v\n", link, err)
			continue
		}
		defer response.Body.Close() // Ensure the response body is closed

		// Read the response body
		body, err := io.ReadAll(response.Body)
		if err != nil {
			fmt.Printf("Error reading response body from %s: %v\n", link, err)
			continue
		}

		// Extract and process words from the response body
		wordRegex := regexp.MustCompile(`\w+`)
		words := wordRegex.FindAllString(string(body), -1)

		// Semaphore for parallel requests for words
		wordSem := make(chan struct{}, 100) // Limit to 100 parallel requests
		var wordWg sync.WaitGroup

		// Process each word with parallelism
		for _, word := range words {
			wordWg.Add(1)

			go func(word string) {
				defer wordWg.Done()

				wordSem <- struct{}{} // Acquire a slot for word processing
				defer func() { <-wordSem }() // Release the slot

				// Build the URL with the word as a GET parameter
				parsedURL, err := url.Parse(link) // Correctly parse the string link
				if err != nil {
					fmt.Printf("Error parsing URL %s: %v\n", link, err)
					return
				}

				query := parsedURL.Query()
				query.Set(word, "xsspear<>")
				parsedURL.RawQuery = query.Encode()
				modifiedLink := parsedURL.String()

				fmt.Printf(" > I: %s\n", modifiedLink)

				// Send a GET request to the modified URL
				resp, err := http.Get(modifiedLink)
				if err != nil {
					fmt.Printf("Error fetching %s: %v\n", modifiedLink, err)
					return
				}
				defer resp.Body.Close()

				// Check for the keyword "xsspear<>" in the response body
				respBody, err := io.ReadAll(resp.Body)
				if err != nil {
					fmt.Printf("Error reading response body from %s: %v\n", modifiedLink, err)
					return
				}

				// Check for the keyword "xsspear<>" in the response body
				if bytes.Contains(respBody, []byte("xsspear<>")) {
					fmt.Printf("xsspear<> found in link %s\n", modifiedLink)

					// Open the output.txt file in append mode
					outputFile, err := os.OpenFile("output.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
					if err != nil {
						fmt.Printf("Error opening output.txt for writing: %v\n", err)
						return
					}
					defer outputFile.Close()

					// Write the link to the file
					_, err = outputFile.WriteString(modifiedLink + "\n")
					if err != nil {
						fmt.Printf("Error writing to output.txt: %v\n", err)
					}
				}
			}(word)
		}

		// Wait for all word requests to finish before moving to the next link
		wordWg.Wait()
	}

	// Wait for all link goroutines to finish
	wg.Wait()
}
